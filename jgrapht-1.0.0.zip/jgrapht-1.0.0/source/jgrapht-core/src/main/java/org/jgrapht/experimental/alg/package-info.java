/**
 * Experimental package with algorithms.
 */
package org.jgrapht.experimental.alg;
