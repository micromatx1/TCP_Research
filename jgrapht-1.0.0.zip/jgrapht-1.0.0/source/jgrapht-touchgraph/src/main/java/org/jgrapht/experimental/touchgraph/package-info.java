/**
 * Integration with the Touchgraph project.
 */
package org.jgrapht.experimental.touchgraph;
